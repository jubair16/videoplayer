package com.example.videoPlayerByME

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
